//var arr=[1,2,3,4,5];
//var doubledArr = arr.map((n)=> n * 2);
//console.log(doubledArr);
//var evenArr = arr.filter((n)=> n % 2 === 0);
//console.log(evenArr);
//var sum = arr.reduce((total, n) => total + n, 0);
//console.log(sum);
//var evenSum = arr.filter((n) => n % 2 === 0).reduce((total, n) => total + n, 0);
//console.log(evenSum);
//var tripleArr = arr.map((n) => n * 3).filter((n) => n % 2!==0).reduce((total, n) => total + n, 0);
//console.log(tripleArr);
var stud=[
    {name:"Takamaura", age:20, grade:85},
    {name:"Rocky", age:22, grade:90},];
var newStud=[...stud, {name:"Mike", age:21, grade:88},{name:"Ali", age:23, grade:92}];
console.log(newStud);